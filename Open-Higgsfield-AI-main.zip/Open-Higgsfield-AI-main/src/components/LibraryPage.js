// MATAI Library - every generated asset from the content-factory backend.
// All media types in one place (images, videos, talking avatars), sorted with
// the newest first. Requires a backend session; prompts sign-in otherwise.
import { cfBackendEnabled, listLibrary, deleteLibraryItem } from '../lib/api.js';
import { sendTo } from '../lib/handoff.js';
import { BackendModal } from './BackendModal.js';
import { getInFlightJobs } from '../lib/pendingJobs.js';

// Escape text that is interpolated into innerHTML templates (prompts and model
// names come from user input / the library backend).
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const safeUrl = (v) => (/^https?:\/\//i.test(String(v || '')) ? esc(v) : '');

// Jobs submitted in this browser that the backend list may not contain yet
// (still being submitted, or the library has not been refreshed).
function localPlaceholders(items) {
    const known = new Set(items.map(it => String(it.taskId || '')).filter(Boolean));
    return getInFlightJobs()
        .filter(j => !known.has(String(j.requestId).replace(/^cf:/, '')))
        .map(j => ({
            id: `local-${j.requestId}`,
            local: true,
            kind: ['video', 'lipsync', 'factory', 'remix'].includes(j.studioType) ? 'videos' : 'images',
            model: j.historyMeta?.model || '',
            prompt: j.historyMeta?.prompt || '',
            status: 'Queued',
            state: 'draft',
            credits: j.historyMeta?.credits ?? null,
            creditStatus: 'estimated',
            duration: j.historyMeta?.duration || null,
            voice: j.historyMeta?.voice ? { name: j.historyMeta.voice } : null,
            createdAt: new Date(j.submittedAt || Date.now()).toISOString(),
        }));
}

const creditText = (item) => (item.credits ? `${item.creditStatus === 'estimated' ? '≈' : ''}${item.credits} cr` : '');

const state = { items: [], filter: 'all', error: '', loaded: false };

function timeAgo(iso) {
    const then = new Date(iso).getTime();
    if (!Number.isFinite(then)) return '';
    const mins = Math.floor((Date.now() - then) / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days}d ago`;
    return new Date(then).toLocaleDateString('en-CA');
}

function kindLabel(item) {
    const model = String(item.model || '').toLowerCase();
    if (/omnihuman|infinitalk|avatar|lipsync/.test(model)) return 'Talking';
    if (Number(item.duration) > 0 || /kling|seedance|wan|video|happyhorse/.test(model)) return 'Video';
    return 'Image';
}

function groupOf(item) {
    return String(item.kind || '').toLowerCase() === 'videos' ? 'videos' : 'images';
}

function filtered() {
    return [...state.items, ...localPlaceholders(state.items)]
        .slice()
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .filter(it => state.filter === 'all' ? true : groupOf(it) === state.filter);
}

function mediaBody(item) {
    if (item.url && item.thumb && groupOf(item) === 'videos') {
        // Video attachments have no image thumbnail; show the frame at 0.5s instead.
        const src = safeUrl(item.url);
        return src ? `<video src="${src}#t=0.5" muted playsinline preload="metadata" class="w-full h-full object-cover"></video>` : '';
    }
    if (item.thumb) return `<img src="${safeUrl(item.thumb)}" alt="${esc(item.model)} result" loading="lazy" class="w-full h-full object-cover">`;
    if (item.state === 'waiting' || item.state === 'draft') {
        return `<div class="w-full h-full flex flex-col items-center justify-center gap-2 bg-white/5">
            <div class="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
            <span class="text-[9px] font-bold uppercase tracking-widest text-secondary">Queued</span>
        </div>`;
    }
    if (item.state === 'failed' || item.status === 'Failed') {
        return `<div class="w-full h-full flex flex-col items-center justify-center gap-2 bg-white/5">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ff2d2d" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>
            <span class="text-[9px] font-bold uppercase tracking-widest text-secondary">Failed</span>
        </div>`;
    }
    return `<div class="w-full h-full flex items-center justify-center bg-white/5">
        <span class="text-[9px] font-bold uppercase tracking-widest text-secondary">No preview</span>
    </div>`;
}

function fileNameFor(item) {
    const ext = groupOf(item) === 'videos' ? 'mp4' : 'png';
    const base = String(item.model || 'matai-result').replace(/\W+/g, '-').replace(/^-+|-+$/g, '') || 'matai-result';
    return `${base}-${String(item.id || '').slice(-6)}.${ext}`;
}

// Save a library item to the device. Streams through the /download-media
// edge function (same-origin, Content-Disposition attachment). On mobile
// browsers that support file sharing, the native share sheet is used so
// the user can save straight to their camera roll / photos.
async function saveToDevice(item, btn) {
    const url = item.sourceUrl || item.url;
    if (!url) return;
    const name = fileNameFor(item);
    const original = btn?.textContent;
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    try {
        const res = await fetch(`/download-media?url=${encodeURIComponent(url)}&name=${encodeURIComponent(name)}`);
        if (!res.ok) throw new Error(`download failed (${res.status})`);
        const blob = await res.blob();
        const file = new File([blob], name, { type: blob.type || item.mime || 'application/octet-stream' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            try {
                await navigator.share({ files: [file] });
                return;
            } catch (err) {
                if (err && err.name === 'AbortError') return; // user dismissed the share sheet
                // share failed for another reason — fall through to download
            }
        }
        const objUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = objUrl;
        a.download = name;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(objUrl), 4000);
    } catch {
        window.open(url, '_blank');
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = original; }
    }
}

// Full-screen preview HUD: big preview, prompt/model details, and
// "Make video", "Edit" and "Redo" open the right studio with this item loaded.
function itemActions(item) {
    const isVideo = groupOf(item) === 'videos';
    const imageUrl = item.sourceUrl || item.url || '';
    const redo = { label: 'Redo', title: 'Open with the same prompt and settings', run: () => sendTo(isVideo ? 'video' : 'image', { mode: 'redo', prompt: item.prompt, model: item.model, aspect: item.aspect, duration: item.duration, resolution: item.resolution }) };
    if (isVideo) return [redo];
    return [
        { label: 'Make video', title: 'Animate this image in the Video tab', run: () => sendTo('video', { mode: 'animate', imageUrl, thumb: item.thumb }) },
        { label: 'Edit', title: 'Change this image in the Image tab', run: () => sendTo('image', { mode: 'edit', imageUrl, thumb: item.thumb }) },
        redo,
    ];
}

// Save to device / Open original actions.
function openPreview(item) {
    const isVideo = groupOf(item) === 'videos';
    const fullUrl = item.url || item.sourceUrl || '';

    const overlay = document.createElement('div');
    overlay.className = 'fixed inset-0 z-[120] bg-black/95 backdrop-blur-sm flex flex-col';
    overlay.innerHTML = `
        <div class="flex items-center justify-between gap-4 px-4 md:px-8 py-4">
            <div class="min-w-0">
                <p class="text-sm font-bold text-white truncate">${esc(item.model) || 'unknown model'}</p>
                <p class="text-[11px] text-secondary truncate">${kindLabel(item)} · ${timeAgo(item.createdAt)}${item.credits ? ` · ${creditText(item)}` : ''}${item.duration ? ` · ${esc(item.duration)}s` : ''}${item.resolution ? ` · ${esc(item.resolution)}` : ''}${item.voice?.name ? ` · voice: ${esc(item.voice.name)}${item.voice.provider === 'elevenlabs' ? ' (your ElevenLabs)' : ''}` : ''}</p>
            </div>
            <button data-close class="shrink-0 w-10 h-10 rounded-full bg-white/10 hover:bg-[#ff2d2d] text-white flex items-center justify-center transition-colors" title="Close">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6 6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="flex-1 min-h-0 flex items-center justify-center px-4 pb-4">
            ${isVideo
                ? `<video src="${safeUrl(fullUrl)}" controls autoplay playsinline class="max-w-full max-h-full rounded-xl shadow-3xl"></video>`
                : `<img src="${safeUrl(fullUrl)}" alt="${esc(item.model)} result" class="max-w-full max-h-full object-contain rounded-xl shadow-3xl">`}
        </div>
        <div class="px-4 md:px-8 pb-6 flex flex-col items-center gap-4">
            ${item.prompt ? `<p class="max-w-3xl text-center text-xs text-secondary leading-relaxed line-clamp-3">${esc(item.prompt)}</p>` : ''}
            <div class="flex items-center gap-3 flex-wrap justify-center">
                <button data-save class="px-6 py-3 rounded-xl bg-primary text-black text-[11px] font-black uppercase tracking-widest shadow-glow hover:scale-105 active:scale-95 transition-all">Save to device</button>
                <a href="${safeUrl(item.sourceUrl || fullUrl)}" target="_blank" rel="noopener" class="px-6 py-3 rounded-xl bg-white/10 text-white text-[11px] font-black uppercase tracking-widest hover:bg-white/20 transition-all">Open original</a>
                <span data-actions class="contents"></span>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);

    const close = () => {
        overlay.remove();
        document.removeEventListener('keydown', onKey);
    };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('[data-close]').onclick = close;
    overlay.querySelector('[data-save]').onclick = (e) => saveToDevice(item, e.currentTarget);
    const actionSlot = overlay.querySelector('[data-actions]');
    itemActions(item).forEach(a => {
        const b = document.createElement('button');
        b.className = 'px-6 py-3 rounded-xl bg-white/10 text-white text-[11px] font-black uppercase tracking-widest hover:bg-primary hover:text-black transition-all';
        b.textContent = a.label;
        b.title = a.title;
        b.onclick = () => { close(); a.run(); };
        actionSlot.appendChild(b);
    });
}

function card(item, onDelete) {
    const ready = Boolean(item.url);

    const card = document.createElement('div');
    card.className = 'group relative rounded-2xl overflow-hidden bg-card-bg border border-white/10 hover:border-primary/50 transition-all duration-300 hover:shadow-glow cursor-pointer hover:scale-[1.02] active:scale-[0.98]';
    card.innerHTML = `
        <div class="aspect-square w-full overflow-hidden bg-black/40">
            ${mediaBody(item)}
        </div>
        <div class="absolute top-3 left-3 flex gap-2 items-center">
            <span class="px-2 py-1 rounded-md bg-black/70 backdrop-blur text-[9px] font-black uppercase tracking-widest text-white border border-white/10">${kindLabel(item)}</span>
            ${ready ? '' : `<span class="px-2 py-1 rounded-md bg-black/70 backdrop-blur text-[9px] font-black uppercase tracking-widest text-primary border border-primary/30">${esc((item.status || item.state || 'draft').toUpperCase())}</span>`}
        </div>
        ${item.credits ? `<span class="absolute bottom-3 right-3 px-2 py-1 rounded-md bg-black/75 text-[10px] font-black text-primary group-hover:opacity-0 transition-opacity">${creditText(item)}</span>` : ''}
        <div class="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/95 via-black/70 to-transparent translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
            <p class="text-[11px] text-white/90 leading-snug line-clamp-2 mb-1">${esc(item.model) || 'unknown model'}</p>
            <p class="text-[10px] text-secondary truncate">${esc(item.prompt)}</p>
            <div class="mt-2 flex items-center gap-2 text-[10px] text-muted">
                <span>${timeAgo(item.createdAt)}</span>
                ${item.credits ? `<span class="text-primary">${creditText(item)}</span>` : ''}
                ${item.duration ? `<span>${esc(item.duration)}s</span>` : ''}
            </div>
        </div>
    `;
    // Red X in the top corner deletes the item from the library.
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'absolute top-3 right-3 z-10 w-7 h-7 rounded-full bg-[#ff2d2d] text-white flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-transform';
    deleteBtn.title = 'Delete from library';
    deleteBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M18 6 6 18M6 6l12 12"/></svg>';
    deleteBtn.onclick = async (e) => {
        e.stopPropagation();
        if (!window.confirm('Delete this item from the library? This cannot be undone.')) return;
        deleteBtn.disabled = true;
        deleteBtn.style.opacity = '0.5';
        try {
            await deleteLibraryItem(item.id);
            if (onDelete) onDelete(item);
        } catch (err) {
            deleteBtn.disabled = false;
            deleteBtn.style.opacity = '';
            alert(err.message || 'Could not delete this item.');
        }
    };
    if (!item.local) card.appendChild(deleteBtn);

    // Make video / Edit / Redo, beside the delete button.
    if (ready && !item.local) {
        const bar = document.createElement('div');
        bar.className = 'absolute top-12 right-3 z-10 flex flex-col items-end gap-1.5 md:opacity-0 md:group-hover:opacity-100 transition-opacity';
        itemActions(item).forEach(a => {
            const b = document.createElement('button');
            b.className = 'h-7 px-2.5 rounded-full bg-black/80 backdrop-blur border border-white/15 text-[10px] font-black text-white hover:bg-primary hover:text-black transition-colors whitespace-nowrap';
            b.textContent = a.label;
            b.title = a.title;
            b.onclick = (e) => { e.stopPropagation(); a.run(); };
            bar.appendChild(b);
        });
        card.appendChild(bar);
    }

    if (ready) {
        card.onclick = () => openPreview(item);
    } else {
        card.style.cursor = 'default';
        card.classList.remove('cursor-pointer', 'hover:scale-[1.02]');
    }
    return card;
}

export function LibraryPage() {
    const page = document.createElement('div');
    page.className = 'flex-1 w-full h-full overflow-y-auto px-4 md:px-10 py-8';

    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-end justify-between mb-6 flex-wrap gap-4';
    headerRow.innerHTML = `
        <div>
            <h1 class="text-3xl font-black tracking-tight text-white mb-1">Library</h1>
            <p class="text-xs text-secondary">All media types, newest first.</p>
        </div>
        <div id="lib-count" class="text-[10px] font-bold uppercase tracking-widest text-muted"></div>
    `;
    page.appendChild(headerRow);
    const countEl = headerRow.querySelector('#lib-count');

    const filters = document.createElement('div');
    filters.className = 'flex items-center gap-2 mb-8 flex-wrap';
    const grid = document.createElement('div');
    grid.className = 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 pb-16';
    page.appendChild(filters);
    page.appendChild(grid);

    let authNote = null;

    const renderGrid = () => {
        const items = filtered();
        countEl.textContent = `${items.length} item${items.length === 1 ? '' : 's'}`;
        grid.innerHTML = '';
        if (!items.length) {
            grid.innerHTML = `<div class="col-span-full flex flex-col items-center justify-center py-24 gap-3 text-center">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--color-muted)" stroke-width="1.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                <p class="text-sm text-secondary">${!state.loaded ? 'Loading your library…' : state.filter === 'all' ? 'Nothing generated yet - your creations land here.' : `No ${state.filter} yet.`}</p>
            </div>`;
        } else {
            items.forEach(item => grid.appendChild(card(item, (deleted) => {
                state.items = state.items.filter(it => it.id !== deleted.id);
                renderGrid();
            })));
        }
    };

    const showAuthNeeded = () => {
        filters.style.display = 'none';
        grid.innerHTML = '';
        countEl.textContent = '0 items';
        if (authNote) { authNote.remove(); authNote = null; }
        const note = document.createElement('div');
        note.className = 'mx-auto max-w-md text-center mt-16 flex flex-col items-center gap-4';
        note.innerHTML = `
            <div class="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center border border-primary/20 shadow-glow mb-2">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#ff2d2d" stroke-width="2"><path d="M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5"/><path d="M8.5 8.5v.01"/></svg>
            </div>
            <p class="text-sm text-secondary leading-relaxed">Sign in to your content-factory account to browse the shared library.</p>
            <button id="lib-signin-btn" class="px-6 py-3 rounded-xl bg-primary text-black text-[11px] font-black uppercase tracking-widest shadow-glow hover:scale-105 active:scale-95 transition-all">Sign in</button>
        `;
        page.appendChild(note);
        note.querySelector('#lib-signin-btn').onclick = () => {
            BackendModal(async () => {
                if (authNote) { authNote.remove(); authNote = null; }
                filters.style.display = 'flex';
                page.$pageRefresh?.();
            });
        };
        authNote = note;
    };

    // Filter chips
    const buttons = {};
    const defs = [
        { key: 'all', label: 'All' },
        { key: 'images', label: 'Images' },
        { key: 'videos', label: 'Videos' },
    ];
    const select = (key) => {
        state.filter = key;
        Object.entries(buttons).forEach(([k, b]) => {
            b.className = k === key
                ? 'px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-widest bg-primary text-black shadow-glow transition-all'
                : 'px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-widest bg-white/5 text-secondary hover:text-white hover:bg-white/10 transition-all';
        });
        renderGrid();
    };
    defs.forEach(({ key, label }) => {
        const b = document.createElement('button');
        b.textContent = label;
        b.onclick = () => select(key);
        buttons[key] = b;
        filters.appendChild(b);
    });

    // Show the last list straight away; the fresh one replaces it when it arrives.
    const CACHE_KEY = 'library_cache';
    try {
        const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
        if (Array.isArray(cached) && cached.length && cfBackendEnabled()) state.items = cached;
    } catch { /* ignore */ }

    const load = async () => {
        if (!cfBackendEnabled()) { showAuthNeeded(); return; }
        try {
            const items = await listLibrary();
            state.items = items || [];
            state.loaded = true;
            try { localStorage.setItem(CACHE_KEY, JSON.stringify(state.items.slice(0, 100))); } catch { /* storage full */ }
            renderGrid();
        } catch (err) {
            if (err.status === 401 || err.status === 403) localStorage.removeItem(CACHE_KEY);
            grid.innerHTML = `<div class="col-span-full text-center py-16 text-sm text-secondary">${esc(err.message || 'Failed to load the library.')}</div>`;
            countEl.textContent = '0 items';
        }
    };

    page.$pageRefresh = load;
    select('all');
    load();

    // Keep queued cards moving: refresh while anything is still generating.
    const hasPending = () => getInFlightJobs().length > 0
        || state.items.some(it => !it.url && !['failed'].includes(it.state) && it.status !== 'Failed');
    let loading = false;
    const timer = setInterval(async () => {
        if (!page.isConnected) { clearInterval(timer); return; }
        if (loading || !cfBackendEnabled()) return;
        if (!hasPending()) return;
        loading = true;
        try { await load(); } finally { loading = false; }
    }, 6000);
    return page;
}